void macska(int a) {

}

int kutya() {}
