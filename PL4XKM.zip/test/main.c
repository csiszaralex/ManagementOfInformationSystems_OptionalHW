int main(char a) {
    return 0;
}

int test(char a, int b) {
    for (int i = 0; i < 10; i++) {
        a = a + 1;
    }
    return a;
}
